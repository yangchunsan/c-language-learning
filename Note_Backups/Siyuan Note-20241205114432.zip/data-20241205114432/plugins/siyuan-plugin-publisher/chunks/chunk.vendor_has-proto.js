var r,t;function n(){if(t)return r;t=1;var o={__proto__:null,foo:{}},e={__proto__:o}.foo===o.foo&&!(o instanceof Object);return r=function(){return e},r}export{n as r};
