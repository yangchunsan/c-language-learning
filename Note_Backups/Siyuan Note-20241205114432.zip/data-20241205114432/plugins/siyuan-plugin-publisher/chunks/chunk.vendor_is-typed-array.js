import{r as i}from"./chunk.vendor_which-typed-array.js";var r,e;function d(){if(e)return r;e=1;var a=i();return r=function(y){return!!a(y)},r}export{d as r};
