var r,a;function i(){if(a)return r;a=1;var t={}.toString;return r=Array.isArray||function(e){return t.call(e)=="[object Array]"},r}export{i as r};
