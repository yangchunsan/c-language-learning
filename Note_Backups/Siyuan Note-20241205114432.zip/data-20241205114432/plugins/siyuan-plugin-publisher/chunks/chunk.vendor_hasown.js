import{r as t}from"./chunk.vendor_function-bind.js";var r,a;function s(){if(a)return r;a=1;var n=Function.prototype.call,o=Object.prototype.hasOwnProperty,e=t();return r=e.call(n,o),r}export{s as r};
