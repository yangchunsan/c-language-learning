import{g as r}from"./chunk.vendor_asn1-js.js";var t={trueFunc:function(){return!0},falseFunc:function(){return!1}};const u=r(t);export{u as a,t as b};
