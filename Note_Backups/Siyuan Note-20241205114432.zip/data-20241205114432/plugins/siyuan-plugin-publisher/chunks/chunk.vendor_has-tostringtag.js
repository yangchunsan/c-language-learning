import{a as e}from"./chunk.vendor_has-symbols.js";var r,a;function m(){if(a)return r;a=1;var s=e();return r=function(){return s()&&!!Symbol.toStringTag},r}export{m as r};
